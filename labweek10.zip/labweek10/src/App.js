import './App.css';
import DataEntryForm from './DataEntryForm.js';

function App() {
  return (
    <div class="App">
     <DataEntryForm />
    </div>
  );
}

export default App;
